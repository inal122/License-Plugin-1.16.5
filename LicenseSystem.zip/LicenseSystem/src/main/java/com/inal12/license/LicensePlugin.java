package com.inal12.license;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.logging.Level;

public class LicensePlugin extends JavaPlugin {

    // SETTINGS
    private final String s1 = "http://localhost";
    private final String s2 = "https://discord.nexoro.com.tr";
    private final int i1 = 2;
    private final String p1 = ChatColor.translateAlternateColorCodes('&', "&8[&dLisans&8] &7");

    @Override
    public void onEnable() {
        Bukkit.getConsoleSender().sendMessage(p1 + "Lisans doğrulanıyor, lutfen bekleyin...");

        if (!v1()) {
            Bukkit.getConsoleSender().sendMessage(p1 + "§cLisans doğrulaması başarısız! Sunucu kapatılıyor...");
            Bukkit.getScheduler().runTaskLater(this, () -> Bukkit.shutdown(), 100L);
        }
    }

    private boolean v1() {
        try {
            String a1 = g1();
            if (a1 == null)
                return false;

            String u1 = s1 + "/api/check?product=" + i1 + "&ip=" + a1;
            URL r1 = new URL(u1);
            HttpURLConnection c1 = (HttpURLConnection) r1.openConnection();
            c1.setRequestMethod("GET");
            c1.setConnectTimeout(5000);
            c1.setReadTimeout(5000);

            if (c1.getResponseCode() == 200) {
                BufferedReader b1 = new BufferedReader(new InputStreamReader(c1.getInputStream()));
                StringBuilder d1 = new StringBuilder();
                String l1;
                while ((l1 = b1.readLine()) != null)
                    d1.append(l1);
                b1.close();

                JsonObject j1 = JsonParser.parseString(d1.toString()).getAsJsonObject();
                if (j1.has("status") && j1.get("status").getAsBoolean()) {
                    String n1 = j1.has("product_name") ? j1.get("product_name").getAsString() : "Unk";
                    String x1 = j1.has("ip") ? j1.get("ip").getAsString() : a1;

                    Bukkit.getConsoleSender().sendMessage(p1 + "§f" + n1.toUpperCase());
                    Bukkit.getConsoleSender().sendMessage(p1 + "§fDiscord: §b" + s2);
                    Bukkit.getConsoleSender().sendMessage(p1 + "§fSite: §b" + s1);
                    Bukkit.getConsoleSender().sendMessage(p1 + "§fLisans IP: §a" + x1);
                    Bukkit.getConsoleSender().sendMessage(p1 + "§a" + n1 + " Lisansi bulundu.");
                    return true;
                }
            }
        } catch (Exception e) {
            Bukkit.getConsoleSender().sendMessage(p1 + "§cErr: " + e.getMessage());
        }
        return false;
    }

    private String g1() {
        try {
            URL r2 = new URL("https://checkip.amazonaws.com");
            BufferedReader b2 = new BufferedReader(new InputStreamReader(r2.openStream()));
            String i2 = b2.readLine().trim();
            b2.close();
            return i2;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public void onDisable() {
        getLogger().info("Plugin disabled.");
    }
}
